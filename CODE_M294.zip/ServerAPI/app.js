
const loginController = require("./controller/00_LoginController");
const http = require("http");
const fs = require("fs");
const { fstat } = require("fs");
const jwt = require("jsonwebtoken");
const express = require("express");

const app = express();
const port = 3000;
app.use(express.json()); // for parsing application/json


app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

const cors = require("cors");
app.use(cors());
app.use(express.static("../client/"))

// ========================================= Zugangspunkte ====================================================
app.get("/", (req, res) => {
	res.send("Zugangspunkte der API:\n/ => Information zur API\nSiehe apiCalls");
});
app.get("/info", (req, res) => {
	res.send({
		Author: "Almir Ajradini",
		Name: "LB M294",
		Company: "BBBaden",
	});
});


function auth(req, res) {
    try {
      const token = req.body.token;
      const jwtData = jwt.verify(token, "mySuperSecretKey");
      if (jwtData) {
        Authentication = true;
        return res.json({
          err: false,
          msg: "authorization complete",
        });
      }
    } catch (error) {
      Authentication = false;
      return res.json({
        err: true,
        msg: "authorization error",
      });
    }
  }
  
// ========================================= Register/Login ===================================================
	app.post("/login", loginController.login);

// ======================================== Start Server ======================================================

app.listen(port, () => {
	console.log(`API listening @ http://localhost:${port}`);
});
